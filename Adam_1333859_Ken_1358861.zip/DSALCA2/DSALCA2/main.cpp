
#include <iostream>
#include "Product.h"
#include "Games.h"
#include "Shop.h"
#include "Admin.h"

using namespace std;

void main()
{
	Shop mainShop;
	mainShop.loadGame();
}



